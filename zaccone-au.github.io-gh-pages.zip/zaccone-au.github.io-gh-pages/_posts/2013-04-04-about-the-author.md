---
layout: post
title: "About the Author"
author: "Paul Le"
categories: journal
tags: [documentation,sample]
image: cutting.jpg
---

Hi there! I'm Paul. I’m a physics major turned programmer. Ever since I first learned how to program while taking a scientific computing for physics course, I have pursued programming as a passion, and as a career. Check out [my personal website](https://www.lenpaul.com/) for more information on my other projects (including more Jekyll themes!), as well as some of my writing.
